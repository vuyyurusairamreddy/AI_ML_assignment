
import joblib
import pandas as pd

model = joblib.load("model/model.pkl")

def predict(data: dict):
    df = pd.DataFrame([data])
    pred = model.predict(df)[0]
    return int(pred)
