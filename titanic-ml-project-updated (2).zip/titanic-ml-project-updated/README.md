
# Titanic Survival Prediction System (ML + API + Deployment)

##  Overview
Production-ready ML system to predict Titanic survival.

Includes:
- Preprocessing pipeline
- Model training + tuning
- FastAPI for predictions
- Docker deployment

##  Architecture
Client → FastAPI → ML Pipeline → Prediction → Response

##  Structure
titanic-ml-project/
├── data/
├── src/
├── api/
├── model/
├── requirements.txt
├── Dockerfile
└── README.md

##  Setup
pip install -r requirements.txt

##  Train Model
python src/train.py

##  Run API
uvicorn api.main:app --reload

## Endpoints
GET /  
POST /predict  

##  Sample Input
{
"Pclass": 3,
"Sex": "male",
"Age": 22,
"Fare": 7.25,
"Embarked": "S"
}

##  Docker
docker build -t titanic-ml .
docker run -p 8000:8000 titanic-ml


