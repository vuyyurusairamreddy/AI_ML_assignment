
from fastapi import FastAPI
from pydantic import BaseModel
from src.predict import predict

app = FastAPI()

class Passenger(BaseModel):
    Pclass: int
    Sex: str
    Age: float
    Fare: float
    Embarked: str

@app.get("/")
def home():
    return {"status": "API is running"}

@app.post("/predict")
def make_prediction(p: Passenger):
    result = predict(p.dict())
    return {"Survived": result}
